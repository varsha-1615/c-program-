#include <stdio.h>

int main(void) {
    double principal, rate, time, interest;

    scanf("%lf %lf %lf", &principal, &rate, &time);
    interest = (principal * rate * time) / 100.0;

    printf("%.2f\n", interest);

    return 0;
}
