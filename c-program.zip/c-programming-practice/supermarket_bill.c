#include <stdio.h>

int main(void) {
    int n, price;
    long long total = 0;

    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        scanf("%d", &price);
        total += price;
    }

    printf("%lld\n", total);

    return 0;
}
