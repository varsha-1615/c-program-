# C Programming Practice 💻

Hi! I'm a first-year Integrated M.Tech CSE student.

This repository contains beginner-level C programs that I'm practicing while learning the fundamentals of programming.

## Programs included
1. Sum of two numbers
2. Simple interest calculator
3. Supermarket total bill
4. Number triangle pattern

## Topics practiced
- `printf()` and `scanf()`
- Variables and data types
- Arithmetic operators
- `for` loops
- Basic problem-solving

## How to run
Compile a program with GCC:

```bash
gcc filename.c -o program
./program
```

On Windows, run the generated `program.exe` instead.

I'm learning one program at a time and will keep adding more practice programs!
